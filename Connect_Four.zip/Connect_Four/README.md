Codes:

1) HTML5 + CSS3 + jQuery, no any other libraries.
2) The number of and the size of the cell in the play board could be changed easily via the global varible named NUM and CELL.
3) It could be Connect Four, Five, Six...
4) I stored jQuery selectors into varibles so that I dont need to select DOM element frequently.
5) When player#0 has not finished(for example in the process of animation), player#1 cant not play. I implemented this with something like lock in operatiing system.


Tests:

1) I used the classical Qunit to test my code.
2) the function I tested is check_board, which is the key function that is used to tell whether one wins or not.
3) I tested my code on Chrome, Safari, Firefox, IE11, Edge.

Links:

1) game link:
http://192.155.81.135/Connect_Four/index.html
2) test link:
http://192.155.81.135/Connect_Four/test.html


